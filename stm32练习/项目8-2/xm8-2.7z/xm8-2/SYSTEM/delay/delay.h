/*************************************
 ***********��ʱ����ͷ�ļ�************
 *************************************/
#ifndef  __DELAY_H
#define  __DELAY_H
void Delay(unsigned int count);
#endif
